var Score = (function () {
    function Score() {
    }
    return Score;
}());
export { Score };
//# sourceMappingURL=Score.js.map