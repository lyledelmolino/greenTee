var PhoneNumber = (function () {
    function PhoneNumber() {
        this.areaCode = '';
        this.exchange = '';
        this.lineNumber = '';
    }
    return PhoneNumber;
}());
export { PhoneNumber };
//# sourceMappingURL=PhoneNumer.js.map