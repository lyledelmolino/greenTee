var Golfer = (function () {
    function Golfer() {
        this.lastName = '';
        this.state = '';
    }
    return Golfer;
}());
export { Golfer };
//# sourceMappingURL=Golfer.js.map