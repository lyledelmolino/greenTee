import { Location } from "./Location";
var User = (function () {
    function User(userLevel) {
        this.emails = [];
        this.locations = [new Location()];
        this.userLevel = 0;
    }
    return User;
}());
export { User };
//# sourceMappingURL=User.js.map