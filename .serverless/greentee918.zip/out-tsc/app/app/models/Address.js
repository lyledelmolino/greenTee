var Address = (function () {
    function Address() {
        this.apartmentNumber = "";
        this.city = "";
        this.state = "";
        this.country = "";
        this.county = "";
        this.streetName = "";
        this.streetNumber = "";
    }
    return Address;
}());
export { Address };
//# sourceMappingURL=Address.js.map