import { Address } from "./Address";
var Location = (function () {
    function Location() {
        this.aAddress = new Address();
    }
    return Location;
}());
export { Location };
//# sourceMappingURL=Location.js.map