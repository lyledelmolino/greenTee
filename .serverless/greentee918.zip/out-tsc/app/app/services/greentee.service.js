import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
var HTTP_OPTIONS = {
    headers: new HttpHeaders({
        'Content-type': 'application/x-www-form-urlencoded'
    })
};
var GreenteeService = (function () {
    function GreenteeService(http) {
        this.http = http;
        this.theURL = 'https://www.greentee.info/angular/api/index.php';
    }
    GreenteeService.prototype.loginUser = function (username, password) {
        var body = new HttpParams();
        body = body.set('username', username);
        body = body.set('password', password);
        body = body.set('action', 'login_api');
        console.log('In greentee.service.ts ---> loginUser(): Observable<User>');
        console.log(body.get('action'));
        return this.http.post(this.theURL, body, HTTP_OPTIONS);
    };
    GreenteeService = tslib_1.__decorate([
        Injectable({
            providedIn: 'root'
        }),
        tslib_1.__metadata("design:paramtypes", [HttpClient])
    ], GreenteeService);
    return GreenteeService;
}());
export { GreenteeService };
//# sourceMappingURL=greentee.service.js.map