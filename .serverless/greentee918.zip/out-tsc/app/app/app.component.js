import * as tslib_1 from "tslib";
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from "@angular/common";
import { environment } from '../environments/environment';
var AppComponent = (function () {
    function AppComponent(platformId, document) {
        this.platformId = platformId;
        this.document = document;
    }
    AppComponent.prototype.ngOnInit = function () {
        if (!isPlatformBrowser(this.platformId)) {
            var bases = this.document.getElementsByTagName('base');
            if (bases.length > 0) {
                bases[0].setAttribute('href', environment.baseHref);
            }
        }
    };
    AppComponent.prototype.setFullViewContainerClasses = function () {
        var classes = {
            fullViewContainer: true
        };
        return classes;
    };
    AppComponent.prototype.setAppContainerClasses = function () {
        var classes = {
            appContainer: true
        };
        return classes;
    };
    AppComponent = tslib_1.__decorate([
        Component({
            selector: 'app-root',
            templateUrl: './app.component.html',
            styleUrls: ['./app.component.css']
        }),
        tslib_1.__param(0, Inject(PLATFORM_ID)), tslib_1.__param(1, Inject(DOCUMENT)),
        tslib_1.__metadata("design:paramtypes", [Object, Object])
    ], AppComponent);
    return AppComponent;
}());
export { AppComponent };
//# sourceMappingURL=app.component.js.map