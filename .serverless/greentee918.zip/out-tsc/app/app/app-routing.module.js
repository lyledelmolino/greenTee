import * as tslib_1 from "tslib";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { GolferSectionComponent } from "./components/golfer-section/golfer-section.component";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { RegisterFreeUserComponent } from "./components/register-free-user/register-free-user.component";
import { LoginComponent } from "./components/login/login.component";
import { ForgotPasswordComponent } from "./components/forgot-password/forgot-password.component";
import { PasswordResetComponent } from "./components/password-reset/password-reset.component";
import { PasswordResetEmailComponent } from "./components/password-reset-email/password-reset-email.component";
import { PinFormComponent } from "./components/pin-form/pin-form.component";
var routes = [
    { path: 'login', component: LoginComponent },
    { path: 'home', component: HomeComponent },
    { path: 'golfer', component: GolferSectionComponent },
    { path: 'register-free-user', component: RegisterFreeUserComponent },
    { path: 'about', component: AboutComponent },
    { path: 'forgot-password', component: ForgotPasswordComponent },
    { path: 'password-reset-email', component: PasswordResetEmailComponent },
    { path: 'initialize-password-reset', component: PinFormComponent },
    { path: 'initialize-subscribe-user', component: PinFormComponent },
    { path: 'password-reset', component: PasswordResetComponent },
    { path: '', redirectTo: '/home', pathMatch: 'full' }
];
var AppRoutingModule = (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib_1.__decorate([
        NgModule({
            imports: [RouterModule.forRoot(routes)],
            exports: [RouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
export { AppRoutingModule };
//# sourceMappingURL=app-routing.module.js.map