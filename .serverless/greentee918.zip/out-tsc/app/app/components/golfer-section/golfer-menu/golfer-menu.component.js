import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../../services/greentee918.service';
var GolferMenuComponent = (function () {
    function GolferMenuComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.scoringComponentVisible = false;
        this.profileComponentVisible = false;
    }
    GolferMenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.greenTee918Service.castScoringComponentVisibility.subscribe(function (visibility) { return _this.scoringComponentVisible = visibility; });
        this.greenTee918Service.castProfileComponentVisibility.subscribe(function (visibility) { return _this.profileComponentVisible = visibility; });
    };
    GolferMenuComponent.prototype.setScoringButtonClasses = function () {
        var classes = {
            active: this.scoringComponentVisible
        };
        return classes;
    };
    GolferMenuComponent.prototype.setProfileButtonClasses = function () {
        var classes = {
            'golfer-menu-button': true,
            active: this.profileComponentVisible
        };
        return classes;
    };
    GolferMenuComponent.prototype.showScoringComponent = function () {
        this.greenTee918Service.showScoringComponent();
        this.greenTee918Service.hideProfileComponent();
    };
    GolferMenuComponent.prototype.showProfileComponent = function () {
        this.greenTee918Service.hideScoringComponent();
        this.greenTee918Service.showProfileComponent();
    };
    GolferMenuComponent = tslib_1.__decorate([
        Component({
            selector: 'app-golfer-menu',
            templateUrl: './golfer-menu.component.html',
            styleUrls: ['../../main-menu/main-menu.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], GolferMenuComponent);
    return GolferMenuComponent;
}());
export { GolferMenuComponent };
//# sourceMappingURL=golfer-menu.component.js.map