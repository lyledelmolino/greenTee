import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
var CurrentScoringRecordComponent = (function () {
    function CurrentScoringRecordComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.currentScoringRecordDetailVisible = false;
    }
    CurrentScoringRecordComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    CurrentScoringRecordComponent.prototype.toggleCurrentScoringRecordDetailVisible = function () {
        this.currentScoringRecordDetailVisible = !this.currentScoringRecordDetailVisible;
    };
    CurrentScoringRecordComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            'form-largest': true,
            active: this.currentScoringRecordDetailVisible
        };
        return classes;
    };
    CurrentScoringRecordComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true
        };
        return classes;
    };
    CurrentScoringRecordComponent.prototype.setScoreTableContainerClass = function () {
        var classes = {
            'score-table-container': true
        };
        return classes;
    };
    CurrentScoringRecordComponent.prototype.setScoringRecordClass = function () {
        var classes = {
            'scoring-record': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], CurrentScoringRecordComponent.prototype, "aGolfer", void 0);
    CurrentScoringRecordComponent = tslib_1.__decorate([
        Component({
            selector: 'app-current-scoring-record',
            templateUrl: './current-scoring-record.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './current-scoring-record.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], CurrentScoringRecordComponent);
    return CurrentScoringRecordComponent;
}());
export { CurrentScoringRecordComponent };
//# sourceMappingURL=current-scoring-record.component.js.map