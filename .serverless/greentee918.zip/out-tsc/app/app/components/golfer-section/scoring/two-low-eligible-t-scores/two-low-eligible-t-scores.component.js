import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
var TwoLowEligibleTScoresComponent = (function () {
    function TwoLowEligibleTScoresComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.detailVisible = false;
    }
    TwoLowEligibleTScoresComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    TwoLowEligibleTScoresComponent.prototype.toggleDetailVisible = function () {
        this.detailVisible = !this.detailVisible;
    };
    TwoLowEligibleTScoresComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            active: this.detailVisible
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true,
            'container-container-container': true
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setContainerContainerContainerClass = function () {
        var classes = {
            'container-container-container': true
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setDetailContainerClass = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setScoreTableContainerClass = function () {
        var classes = {
            'score-table-container': true
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setScoringRecordContainerClass = function () {
        var classes = {
            'scoring-record-container': true
        };
        return classes;
    };
    TwoLowEligibleTScoresComponent.prototype.setScoringRecordClass = function () {
        var classes = {
            'score-table': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], TwoLowEligibleTScoresComponent.prototype, "scores", void 0);
    TwoLowEligibleTScoresComponent = tslib_1.__decorate([
        Component({
            selector: 'app-two-low-eligible-t-scores',
            templateUrl: './two-low-eligible-t-scores.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './two-low-eligible-t-scores.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], TwoLowEligibleTScoresComponent);
    return TwoLowEligibleTScoresComponent;
}());
export { TwoLowEligibleTScoresComponent };
//# sourceMappingURL=two-low-eligible-t-scores.component.js.map