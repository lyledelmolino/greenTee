import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
var ScoreComponent = (function () {
    function ScoreComponent() {
    }
    ScoreComponent.prototype.ngOnInit = function () {
    };
    ScoreComponent.prototype.setScoreTableClass = function () {
        var classes = {
            'score-table': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], ScoreComponent.prototype, "scores", void 0);
    ScoreComponent = tslib_1.__decorate([
        Component({
            selector: 'app-score',
            templateUrl: './score.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './score.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], ScoreComponent);
    return ScoreComponent;
}());
export { ScoreComponent };
//# sourceMappingURL=score.component.js.map