import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
var TournamentScoringRecordComponent = (function () {
    function TournamentScoringRecordComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.detailVisible = false;
    }
    TournamentScoringRecordComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    TournamentScoringRecordComponent.prototype.toggleTournamentScoringRecordDetailVisible = function () {
        this.detailVisible = !this.detailVisible;
    };
    TournamentScoringRecordComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            active: this.detailVisible
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true,
            'container-container-container': true
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setContainerContainerContainerClass = function () {
        var classes = {
            'container-container': true
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setScoreTableContainerClass = function () {
        var classes = {
            'score-table-container': true
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setScoringRecordContainerClass = function () {
        var classes = {
            'scoring-record-container': true
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setDetailContainerClass = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    TournamentScoringRecordComponent.prototype.setScoringRecordClass = function () {
        var classes = {
            'score-table': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], TournamentScoringRecordComponent.prototype, "scores", void 0);
    TournamentScoringRecordComponent = tslib_1.__decorate([
        Component({
            selector: 'app-tournament-scoring-record',
            templateUrl: './tournament-scoring-record.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './tournament-scoring-record.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], TournamentScoringRecordComponent);
    return TournamentScoringRecordComponent;
}());
export { TournamentScoringRecordComponent };
//# sourceMappingURL=tournament-scoring-record.component.js.map