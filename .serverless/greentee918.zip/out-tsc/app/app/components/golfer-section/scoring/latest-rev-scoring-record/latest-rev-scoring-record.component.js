import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
var LatestRevScoringRecordComponent = (function () {
    function LatestRevScoringRecordComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.latestRevScoringRecordDetailVisible = false;
    }
    LatestRevScoringRecordComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.aFreeUser = user; });
        console.log('In latest-rev-scoring-record.component.ts - ngOnInit()!!');
        console.log(this.aGolfer.clubRoles[0].club.clubId);
    };
    LatestRevScoringRecordComponent.prototype.setTournamentScoringRecordClasses = function () {
        var classes = {
            'scoring-record-component': true
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.setScoreTableContainerClass = function () {
        var classes = {
            'score-table-container': true
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.setTwoLowEligibleTScoresClasses = function () {
        var classes = {
            twoLowEligibleTScores: true
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.toggleLatestRevScoringRecordDetailVisible = function () {
        this.latestRevScoringRecordDetailVisible = !this.latestRevScoringRecordDetailVisible;
    };
    LatestRevScoringRecordComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            'form-largest': true,
            active: this.latestRevScoringRecordDetailVisible
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.setDetailContainerClass = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    LatestRevScoringRecordComponent.prototype.setScoringRecordClass = function () {
        var classes = {
            'score-table': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], LatestRevScoringRecordComponent.prototype, "aFreeUser", void 0);
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], LatestRevScoringRecordComponent.prototype, "aGolfer", void 0);
    LatestRevScoringRecordComponent = tslib_1.__decorate([
        Component({
            selector: 'app-latest-rev-scoring-record',
            templateUrl: './latest-rev-scoring-record.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './latest-rev-scoring-record.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], LatestRevScoringRecordComponent);
    return LatestRevScoringRecordComponent;
}());
export { LatestRevScoringRecordComponent };
//# sourceMappingURL=latest-rev-scoring-record.component.js.map