import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../../services/greentee918.service';
var ScoringComponent = (function () {
    function ScoringComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
    }
    ScoringComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    ScoringComponent.prototype.setScoringComponentClasses = function () {
        var classes = {
            'scoring-group-component container-container': true,
        };
        return classes;
    };
    ScoringComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    ScoringComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true
        };
        return classes;
    };
    ScoringComponent.prototype.setPostScoreClasses = function () {
        var classes = {
            'post-score': true
        };
        return classes;
    };
    ScoringComponent.prototype.setScoringRecordClasses = function () {
        var classes = {
            'scoring-record': true
        };
        return classes;
    };
    ScoringComponent.prototype.setCurrentScoringRecordClasses = function () {
        var classes = {
            'current-scoring-record': true
        };
        return classes;
    };
    ScoringComponent = tslib_1.__decorate([
        Component({
            selector: 'app-scoring',
            templateUrl: './scoring.component.html',
            styleUrls: ['../../../app.component.css', './scoring.component.css'],
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], ScoringComponent);
    return ScoringComponent;
}());
export { ScoringComponent };
//# sourceMappingURL=scoring.component.js.map