import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
import { Score } from '../../../../models/Score';
import { trigger, state, style, animate, transition, } from '@angular/animations';
var PostScoreComponent = (function () {
    function PostScoreComponent(greenTee918Service) {
        var _this = this;
        this.greenTee918Service = greenTee918Service;
        this.state = 'closed';
        this.checked = 'checked';
        this.postScoreDetailVisible = false;
        this.scoreToPost = new Score();
        this.scoreNumberOnly = "";
        this.scoreValid = true;
        this.courseRatingNumberOnly = "";
        this.courseRatingValid = true;
        this.slopeNumberOnly = "";
        this.slopeValid = false;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.scoreToPost = {
            date: '',
            score: '',
            course_rating: '',
            slope: '',
            number_of_holes: '18',
            home_away: 'H',
            tournament_score: '',
            golfer_id: this.appUser.id,
            post_person_id: this.appUser.id
        };
    }
    PostScoreComponent.prototype.ngOnInit = function () {
    };
    PostScoreComponent.prototype.ngDoCheck = function () {
    };
    PostScoreComponent.prototype.postScore = function () {
        this.greenTee918Service.postScore(this.scoreToPost);
    };
    PostScoreComponent.prototype.inputMaxChars = function (e) {
        console.log("In inputMaxChars START **********************************************");
        console.log("In inputMaxChars(1) this.scoreToPost.score: " + this.scoreToPost.score);
        console.log("In inputMaxChars(1) this.scoreToPost.score.length: " + this.scoreToPost.score.length);
        if (this.scoreToPost.score.length > 3) {
            console.log("In inputMaxChars(2) this.scoreToPost.score: " + this.scoreToPost.score);
            this.scoreToPost.score = this.scoreToPost.score.substring(0, this.scoreToPost.score.length - 1);
        }
    };
    PostScoreComponent.prototype.inputOnlyIntegerScore = function (e) {
        console.log("In inputOnlyIntegerScore START **********************************************");
        console.log("In inputOnlyIntegerScore(1) this.scoreToPost.score: " + this.scoreToPost.score);
        this.input_value = this.scoreToPost.score + e.key;
        console.log("In inputOnlyIntegerScore(1) e.key: " + e.key);
        if (parseInt(this.scoreToPost.score) > 20 && parseInt(this.scoreToPost.score) < 200) {
            this.input_value = this.input_value + ' valid';
            this.scoreValid = true;
        }
        else {
            this.input_value = this.input_value + ' invalid';
            this.scoreValid = false;
        }
        return;
    };
    PostScoreComponent.prototype.inputOnlyIntegerSlope = function (e) {
        this.input_value = this.scoreToPost.slope;
        console.log("In inputOnlyIntegerSlope(1) e.key: " + e.key);
        if (e.key.toLowerCase() == 'unidentified') {
            this.slopeValid = true;
            return;
        }
        if (parseInt(this.scoreToPost.slope) > 26 && parseInt(this.scoreToPost.slope) < 156) {
            this.slopeValid = true;
        }
        else {
            this.slopeValid = false;
        }
        var input = parseInt(e.key);
        if ((e.shiftKey || (isNaN(input)))
            && e.key !== "Backspace"
            && e.key !== " "
            && e.key !== "Delete") {
            console.log("In suppress keystroke");
            console.log("In inputOnlyIntegerSlope(2) e.key: " + e.key);
            console.log("In inputOnlyIntegerSlope(2) parseInt(e.key): " + parseInt(e.key));
            console.log("In inputOnlyIntegerSlope(4) this.scoreToPost.slope: " + this.scoreToPost.slope);
            console.log("In inputOnlyIntegerSlope END (ignore) **********************************************");
            return false;
        }
        return;
    };
    PostScoreComponent.prototype.inputOnlyCourseRating = function (e) {
        this.input_value = this.scoreToPost.course_rating;
        if (e.key.toLowerCase() == 'unidentified') {
            this.courseRatingValid = true;
            return true;
        }
        var input = parseInt(e.key);
        if ((e.shiftKey || (isNaN(input)))
            && e.key !== "Backspace"
            && e.key !== " "
            && e.key !== "Delete") {
            if (this.scoreToPost.course_rating.length == 3 && e.key == ".") {
                this.courseRatingNumberOnly = this.scoreToPost.course_rating + e.key;
                return true;
            }
            this.scoreToPost.course_rating = this.scoreToPost.course_rating.substring(0, this.scoreToPost.course_rating.length - 1);
            return false;
        }
        if (this.scoreToPost.course_rating.length == 3 && !isNaN(input)) {
            this.scoreToPost.course_rating = this.scoreToPost.course_rating.substring(0, this.scoreToPost.course_rating.length - 1);
            return false;
        }
        return true;
    };
    PostScoreComponent.prototype.isIntegerValid = function (e) {
        var input = parseInt(e.key);
        if ((e.shiftKey || (isNaN(input)))
            && e.key !== "Backspace"
            && e.key !== " "
            && e.key !== "Delete"
            && e.key !== 37
            && e.key !== 39
            && e.key !== 9) {
            return false;
        }
        return true;
    };
    PostScoreComponent.prototype.togglePostScoreDetailVisible = function () {
        this.postScoreDetailVisible = !this.postScoreDetailVisible;
    };
    PostScoreComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            'form-largest': true,
            'post-score': true,
            active: this.postScoreDetailVisible
        };
        return classes;
    };
    PostScoreComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true
        };
        return classes;
    };
    PostScoreComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    PostScoreComponent.prototype.setPostScoreClasses = function () {
        var classes = {
            'post-score-form': true
        };
        return classes;
    };
    PostScoreComponent.prototype.setChecked = function () {
        var checked = {
            'checked': true
        };
        return checked;
    };
    PostScoreComponent.prototype.setPostScoreFormClasses = function () {
        var classes = {
            'form-horizontal': true
        };
        return classes;
    };
    PostScoreComponent = tslib_1.__decorate([
        Component({
            selector: 'app-post-score',
            templateUrl: './post-score.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './post-score.component.css'],
            animations: [
                trigger('toggle', [
                    state('open', style({ height: '320px' })),
                    state('closed', style({ height: '*' })),
                    transition('open <=> closed', animate('200ms ease-in-out'))
                ])
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], PostScoreComponent);
    return PostScoreComponent;
}());
export { PostScoreComponent };
//# sourceMappingURL=post-score.component.js.map