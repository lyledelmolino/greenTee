import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var GolferSectionComponent = (function () {
    function GolferSectionComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.scoringComponentVisible = false;
        this.profileComponentVisible = false;
    }
    GolferSectionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castScoringComponentVisibility.subscribe(function (visibility) { return _this.scoringComponentVisible = visibility; });
        this.greenTee918Service.castProfileComponentVisibility.subscribe(function (visibility) { return _this.profileComponentVisible = visibility; });
    };
    GolferSectionComponent.prototype.setGolferMenuClasses = function () {
        var classes = {
            'golfer-menu': true
        };
        return classes;
    };
    GolferSectionComponent.prototype.setScoringClasses = function () {
        var classes = {
            scoring: true
        };
        return classes;
    };
    GolferSectionComponent.prototype.setProfileClasses = function () {
        var classes = {
            profile: true
        };
        return classes;
    };
    GolferSectionComponent = tslib_1.__decorate([
        Component({
            selector: 'app-golfer-section',
            templateUrl: './golfer-section.component.html',
            styleUrls: ['../../app.component.css', './golfer-section.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], GolferSectionComponent);
    return GolferSectionComponent;
}());
export { GolferSectionComponent };
//# sourceMappingURL=golfer-section.component.js.map