import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var PhoneComponent = (function () {
    function PhoneComponent() {
    }
    PhoneComponent.prototype.ngOnInit = function () {
    };
    PhoneComponent = tslib_1.__decorate([
        Component({
            selector: 'app-phone',
            templateUrl: './phone.component.html',
            styleUrls: ['./phone.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], PhoneComponent);
    return PhoneComponent;
}());
export { PhoneComponent };
//# sourceMappingURL=phone.component.js.map