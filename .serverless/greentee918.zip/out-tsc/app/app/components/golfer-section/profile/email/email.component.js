import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var EmailComponent = (function () {
    function EmailComponent() {
    }
    EmailComponent.prototype.ngOnInit = function () {
    };
    EmailComponent = tslib_1.__decorate([
        Component({
            selector: 'app-email',
            templateUrl: './email.component.html',
            styleUrls: ['./email.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], EmailComponent);
    return EmailComponent;
}());
export { EmailComponent };
//# sourceMappingURL=email.component.js.map