import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var AddressComponent = (function () {
    function AddressComponent() {
    }
    AddressComponent.prototype.ngOnInit = function () {
    };
    AddressComponent = tslib_1.__decorate([
        Component({
            selector: 'app-address',
            templateUrl: './address.component.html',
            styleUrls: ['./address.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], AddressComponent);
    return AddressComponent;
}());
export { AddressComponent };
//# sourceMappingURL=address.component.js.map