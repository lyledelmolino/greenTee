import * as tslib_1 from "tslib";
import { Component, ElementRef } from '@angular/core';
import { Greentee918Service } from '../../../services/greentee918.service';
import { User } from '../../../models/User';
import { PhoneNumber } from '../../../models/PhoneNumer';
var ProfileComponent = (function () {
    function ProfileComponent(greenTee918Service) {
        var _this = this;
        this.greenTee918Service = greenTee918Service;
        this.affiliationsDetailVisible = false;
        this.addressDetailVisible = false;
        this.emailDetailVisible = false;
        this.phoneDetailVisible = false;
        this.updatedUser = new User();
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.componentUser = JSON.parse(JSON.stringify(this.appUser));
        if (this.componentUser === null && this.componentUser.phoneNumbers.length === 0) {
            this.componentUser.phoneNumbers.push(new PhoneNumber());
        }
    }
    ProfileComponent.prototype.ngOnInit = function () {
    };
    ProfileComponent.prototype.updateUserProfile = function () {
        this.greenTee918Service.updateUserProfile(this.componentUser);
    };
    ProfileComponent.prototype.inputOnlyInteger = function (e, maxlength) {
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)
            && e.keyCode !== 8
            && e.keyCode !== 46
            && e.keyCode !== 37
            && e.keyCode !== 39
            && e.keyCode !== 9) {
            e.preventDefault();
            return;
        }
        if (typeof maxlength !== 'undefined' && maxlength != null
            && e.target.value.length >= maxlength
            && e.keyCode !== 8
            && e.keyCode !== 46
            && e.keyCode !== 37
            && e.keyCode !== 39
            && e.keyCode !== 9) {
            e.preventDefault();
            return;
        }
    };
    ProfileComponent.prototype.checkInputForTab = function (e) {
        if (e.target.value.length === 3) {
            var next = new ElementRef(e.target.nextSibling);
            next.nativeElement.focus();
            e.target.value = e.target.value;
        }
    };
    ProfileComponent.prototype.resetForm = function () {
        this.componentUser = JSON.parse(JSON.stringify(this.appUser));
    };
    ProfileComponent.prototype.toggleAffiliationsDetailVisible = function () {
        this.affiliationsDetailVisible = !this.affiliationsDetailVisible;
    };
    ProfileComponent.prototype.toggleAddressDetailVisible = function () {
        this.addressDetailVisible = !this.addressDetailVisible;
    };
    ProfileComponent.prototype.toggleEmailDetailVisible = function () {
        this.emailDetailVisible = !this.emailDetailVisible;
    };
    ProfileComponent.prototype.togglePhoneDetailVisible = function () {
        this.phoneDetailVisible = !this.phoneDetailVisible;
    };
    ProfileComponent.prototype.setAddressContainerClasses = function () {
        var classes = {
            address: true
        };
        return classes;
    };
    ProfileComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            'form-largest': true
        };
        return classes;
    };
    ProfileComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true,
            'profile-group-component': true
        };
        return classes;
    };
    ProfileComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    ProfileComponent.prototype.setProfileClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    ProfileComponent.prototype.setProfileDetailContainerClasses = function () {
        var classes = {
            'profile-detail': true
        };
        return classes;
    };
    ProfileComponent.prototype.setProfileAffiliationsDetailContainerClasses = function () {
        var classes = {
            'profile-affiliations-detail': true
        };
        return classes;
    };
    ProfileComponent = tslib_1.__decorate([
        Component({
            selector: 'app-profile',
            templateUrl: './profile.component.html',
            styleUrls: ['../../../app.component.css', '../scoring/scoring.component.css', './profile.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], ProfileComponent);
    return ProfileComponent;
}());
export { ProfileComponent };
//# sourceMappingURL=profile.component.js.map