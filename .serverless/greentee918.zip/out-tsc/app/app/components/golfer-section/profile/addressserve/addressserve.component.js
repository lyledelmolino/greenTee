import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var AddressserveComponent = (function () {
    function AddressserveComponent() {
    }
    AddressserveComponent.prototype.ngOnInit = function () {
    };
    AddressserveComponent = tslib_1.__decorate([
        Component({
            selector: 'app-addressserve',
            templateUrl: './addressserve.component.html',
            styleUrls: ['./addressserve.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], AddressserveComponent);
    return AddressserveComponent;
}());
export { AddressserveComponent };
//# sourceMappingURL=addressserve.component.js.map