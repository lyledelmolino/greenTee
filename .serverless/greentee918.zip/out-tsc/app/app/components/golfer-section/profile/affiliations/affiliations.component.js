import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var AffiliationsComponent = (function () {
    function AffiliationsComponent() {
    }
    AffiliationsComponent.prototype.ngOnInit = function () {
    };
    AffiliationsComponent = tslib_1.__decorate([
        Component({
            selector: 'app-affiliations',
            templateUrl: './affiliations.component.html',
            styleUrls: ['./affiliations.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], AffiliationsComponent);
    return AffiliationsComponent;
}());
export { AffiliationsComponent };
//# sourceMappingURL=affiliations.component.js.map