import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
import { User } from '../../models/User';
var FreeTrialComponent = (function () {
    function FreeTrialComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.freeTrialUser = new User();
    }
    FreeTrialComponent.prototype.ngOnInit = function () { };
    FreeTrialComponent.prototype.setFreeTrialFormClasses = function () {
        var classes = {
            'free-trial-form': true
        };
        return classes;
    };
    FreeTrialComponent.prototype.setFreeTrialContainerClasses = function () {
        var classes = {
            'free-trial-container': true
        };
        return classes;
    };
    FreeTrialComponent.prototype.registerFreeTrialUser = function () {
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.showPinFormComponent();
    };
    FreeTrialComponent.prototype.cancel = function () {
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.showHomeComponent();
    };
    FreeTrialComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true,
            'profile-group-component': true
        };
        return classes;
    };
    FreeTrialComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    FreeTrialComponent.prototype.setProfileClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    FreeTrialComponent = tslib_1.__decorate([
        Component({
            selector: 'app-free-trial',
            templateUrl: './free-trial.component.html',
            styleUrls: ['../../app.component.css', './free-trial.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], FreeTrialComponent);
    return FreeTrialComponent;
}());
export { FreeTrialComponent };
//# sourceMappingURL=free-trial.component.js.map