import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../../services/greentee918.service';
var PinFormComponent = (function () {
    function PinFormComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
    }
    PinFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castRegisterForFreeTrialSessionId.
            subscribe(function (sessionId) { return _this.freeTrialRegistrationSessionId = sessionId; });
    };
    PinFormComponent.prototype.cancel = function () {
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.showHomeComponent();
    };
    PinFormComponent.prototype.finalizeFreeTrialRegistration = function () {
        console.log('In PinFormComponent.ts ---> finalizeFreeTrialRegistration()');
        console.log(this.freeTrialRegistrationSessionId);
        this.greenTee918Service.finalizeFreeTrialRegistration(this.freeTrialRegistrationPin, this.freeTrialRegistrationSessionId);
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.showHomeComponent();
    };
    PinFormComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true,
            'profile-group-component': true
        };
        return classes;
    };
    PinFormComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    PinFormComponent.prototype.setProfileClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    PinFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-pin-form',
            templateUrl: './pin-form.component.html',
            styleUrls: ['../../../app.component.css', '../free-trial.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], PinFormComponent);
    return PinFormComponent;
}());
export { PinFormComponent };
//# sourceMappingURL=pin-form.component.js.map