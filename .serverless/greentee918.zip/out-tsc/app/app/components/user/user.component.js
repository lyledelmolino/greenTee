import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Greentee918Service } from '../../services/greentee918.service';
var UserComponent = (function () {
    function UserComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
    }
    UserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    UserComponent.prototype.backClicked = function () {
        console.log("back clicked!");
    };
    UserComponent.prototype.setLoginClasses = function () {
        var classes = {
            login: true
        };
        return classes;
    };
    UserComponent.prototype.setLoginButtonClasses = function () {
        var classes = {
            'login-button': true
        };
        return classes;
    };
    UserComponent.prototype.setUserComponentClasses = function () {
        var classes = {
            user: true
        };
        return classes;
    };
    UserComponent.prototype.showLoginComponent = function () {
        this.greenTee918Service.showLoginComponent();
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideFoundGolfersComponent();
        this.greenTee918Service.hideAboutComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
    };
    UserComponent.prototype.logoutUser = function () {
        this.greenTee918Service.logoutUser(this.router);
        this.greenTee918Service.hideResponsiveMenu();
    };
    UserComponent = tslib_1.__decorate([
        Component({
            selector: 'app-user',
            templateUrl: './user.component.html',
            styleUrls: ['./user.component.css', '../../app.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], UserComponent);
    return UserComponent;
}());
export { UserComponent };
//# sourceMappingURL=user.component.js.map