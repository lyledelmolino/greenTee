import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var HomeComponent = (function () {
    function HomeComponent(greenTee918Service) {
        var _this = this;
        this.greenTee918Service = greenTee918Service;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    HomeComponent.prototype.showRegisterFreeUserComponent = function () {
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideAboutComponent();
        this.greenTee918Service.showRegisterFreeTrialUserComponent();
        this.greenTee918Service.hidePinFormComponent();
    };
    HomeComponent.prototype.setFindGolferClasses = function () {
        var classes = {
            'find-golfer': true
        };
        return classes;
    };
    HomeComponent = tslib_1.__decorate([
        Component({
            selector: 'app-home',
            templateUrl: './home.component.html',
            styleUrls: ['../../app.component.css', './home.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], HomeComponent);
    return HomeComponent;
}());
export { HomeComponent };
//# sourceMappingURL=home.component.js.map