import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { Greentee918Service } from '../../services/greentee918.service';
var PasswordResetComponent = (function () {
    function PasswordResetComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
    }
    PasswordResetComponent.prototype.ngOnInit = function () {
    };
    PasswordResetComponent.prototype.cancel = function () {
        this.greenTee918Service.hidePasswordResetComponent();
        this.greenTee918Service.showForgotPasswordComponent();
    };
    PasswordResetComponent.prototype.resetPassword = function () {
        if (this.password == this.passwordConfirm) {
            this.greenTee918Service.resetPassword(this.password, this.router);
        }
    };
    PasswordResetComponent.prototype.setResetPasswordFormClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    PasswordResetComponent.prototype.setResetPasswordContainerClasses = function () {
        var classes = {
            'login-container': true
        };
        return classes;
    };
    PasswordResetComponent = tslib_1.__decorate([
        Component({
            selector: 'app-password-reset',
            templateUrl: './password-reset.component.html',
            styleUrls: ['../../app.component.css', './password-reset.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], PasswordResetComponent);
    return PasswordResetComponent;
}());
export { PasswordResetComponent };
//# sourceMappingURL=password-reset.component.js.map