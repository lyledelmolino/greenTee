import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var ForgotPasswordComponent = (function () {
    function ForgotPasswordComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
    }
    ForgotPasswordComponent.prototype.ngOnInit = function () {
    };
    ForgotPasswordComponent.prototype.setFullViewContainerClasses = function () {
        var classes = {
            fullViewContainer: true
        };
        return classes;
    };
    ForgotPasswordComponent.prototype.setHeaderClasses = function () {
        var classes = {
            'login-header': true
        };
        return classes;
    };
    ForgotPasswordComponent.prototype.setForgotPasswordContainerClasses = function () {
        var classes = {
            'login-container': true
        };
        return classes;
    };
    ForgotPasswordComponent.prototype.setForgotPasswordFormClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    ForgotPasswordComponent.prototype.cancel = function () {
        this.greenTee918Service.hideForgotPasswordComponent();
        this.greenTee918Service.showLoginFormComponent();
    };
    ForgotPasswordComponent.prototype.showPasswordResetEmailComponent = function () {
        this.greenTee918Service.showPasswordResetEmailComponent();
        this.greenTee918Service.hideForgotPasswordComponent();
    };
    ForgotPasswordComponent.prototype.showPasswordResetPhoneComponent = function () {
        this.greenTee918Service.showPasswordResetPhoneComponent();
        this.greenTee918Service.hideForgotPasswordComponent();
    };
    ForgotPasswordComponent = tslib_1.__decorate([
        Component({
            selector: 'app-forgot-password',
            templateUrl: './forgot-password.component.html',
            styleUrls: ['../../app.component.css', './forgot-password.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], ForgotPasswordComponent);
    return ForgotPasswordComponent;
}());
export { ForgotPasswordComponent };
//# sourceMappingURL=forgot-password.component.js.map