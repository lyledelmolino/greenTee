import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { Greentee918Service } from '../../services/greentee918.service';
var MainAppComponent = (function () {
    function MainAppComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
        this.loginComponentVisible = false;
    }
    MainAppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.greenTee918Service.loginUser('not_logged_in', 'password', this.router);
        this.greenTee918Service.castLoginVisibility.subscribe(function (user) { return _this.loginComponentVisible = user; });
        this.greenTee918Service.showHomeComponent();
    };
    MainAppComponent.prototype.setAppUserClasses = function () {
        var classes = {};
        return classes;
    };
    MainAppComponent.prototype.setHeaderClasses = function () {
        var classes = {
            'app-header': true
        };
        return classes;
    };
    MainAppComponent.prototype.setFullViewContainerClasses = function () {
        var classes = {
            fullViewContainer: true
        };
        return classes;
    };
    MainAppComponent.prototype.setMainContentClasses = function () {
        var classes = {
            'app-main-content': true
        };
        return classes;
    };
    MainAppComponent.prototype.showLoginComponent = function () {
        this.loginComponentVisible = true;
    };
    MainAppComponent.prototype.hideLoginComponent = function () {
    };
    MainAppComponent = tslib_1.__decorate([
        Component({
            selector: 'app-main-app',
            templateUrl: './main-app.component.html',
            styleUrls: ['../../app.component.css', './main-app.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], MainAppComponent);
    return MainAppComponent;
}());
export { MainAppComponent };
//# sourceMappingURL=main-app.component.js.map