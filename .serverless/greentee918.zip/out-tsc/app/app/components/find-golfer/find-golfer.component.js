import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
import { Golfer } from '../../models/Golfer';
var FindGolferComponent = (function () {
    function FindGolferComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.golferToFind = new Golfer();
        this.searchGolferVisible = true;
        this.foundGolfersVisible = false;
        this.foundGolfersScoringRecordVisible = [''];
    }
    FindGolferComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castFoundGolfers.subscribe(function (foundGolfers) { return _this.foundGolfers = foundGolfers; });
        this.golferToFind.state = "state";
    };
    FindGolferComponent.prototype.findGolfer = function () {
        var _this = this;
        if (this.golferToFind.lastName != null && this.golferToFind.lastName != '') {
            this.greenTee918Service.findGolfer(this.golferToFind);
            this.searchGolferVisible = false;
            this.foundGolfers.forEach(function (index) {
                _this.foundGolfersScoringRecordVisible[index] = false;
            });
        }
        else {
            this.greenTee918Service.hideFoundGolfersComponent();
        }
    };
    FindGolferComponent.prototype.searchAgain = function () {
        this.searchGolferVisible = true;
        this.foundGolfers = null;
    };
    FindGolferComponent.prototype.toggleFoundGolfersScoringRecordVisible = function (index, event) {
        this.foundGolfersScoringRecordVisible[index] = !this.foundGolfersScoringRecordVisible[index];
    };
    FindGolferComponent.prototype.toggleReset = function (e) {
    };
    FindGolferComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setListContainerClasses = function () {
        var classes = {
            'list-container': true,
        };
        return classes;
    };
    FindGolferComponent.prototype.setListItemContainerClasses = function () {
        var classes = {
            'list-item-container': true,
        };
        return classes;
    };
    FindGolferComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true,
            'show-container': this.searchGolferVisible,
            'hide-container': !this.searchGolferVisible
        };
        return classes;
    };
    FindGolferComponent.prototype.setFindGolferClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setScoringComponentClasses = function () {
        var classes = {
            'scoring-group-component': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setPostScoreClasses = function () {
        var classes = {
            'post-score': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setScoringRecordClasses = function () {
        var classes = {
            'scoring-record': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setCurrentScoringRecordClasses = function () {
        var classes = {
            'current-scoring-record': true
        };
        return classes;
    };
    FindGolferComponent.prototype.setTriangleAcuatorClasses = function () {
        var classes = {
            'triangle-down': true,
            'triangle-up': true,
        };
        return classes;
    };
    FindGolferComponent.prototype.setSelectStateClasses = function () {
        var classes = {
            'form-largest': true,
            'grey-default': this.golferToFind.state == 'state'
        };
        return classes;
    };
    FindGolferComponent = tslib_1.__decorate([
        Component({
            selector: 'app-find-golfer',
            templateUrl: './find-golfer.component.html',
            styleUrls: ['../../app.component.css', './find-golfer.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], FindGolferComponent);
    return FindGolferComponent;
}());
export { FindGolferComponent };
//# sourceMappingURL=find-golfer.component.js.map