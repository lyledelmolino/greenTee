import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var MainContentComponent = (function () {
    function MainContentComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.homeComponentVisible = true;
        this.golferComponentVisible = false;
        this.clubAdminComponentVisible = false;
        this.adminComponentVisible = false;
        this.aboutComponentVisible = false;
        this.freeTrialComponentVisible = false;
        this.freeUserPinFormComponentVisible = false;
        this.registerFreeUserComponentVisible = false;
    }
    MainContentComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.greenTee918Service.castHomeComponentVisibility.subscribe(function (visibility) { return _this.homeComponentVisible = visibility; });
        this.greenTee918Service.castGolferComponentVisibility.subscribe(function (visibility) { return _this.golferComponentVisible = visibility; });
        this.greenTee918Service.castClubAdminComponentVisibility.subscribe(function (visibility) { return _this.clubAdminComponentVisible = visibility; });
        this.greenTee918Service.castAdminComponentVisibility.subscribe(function (visibility) { return _this.adminComponentVisible = visibility; });
        this.greenTee918Service.castAboutComponentVisibility.subscribe(function (visibility) { return _this.aboutComponentVisible = visibility; });
        this.greenTee918Service.castRegisterFreeUserComponentVisibility.subscribe(function (visibility) {
            return _this.registerFreeUserComponentVisible = visibility;
        });
        this.greenTee918Service.castFreeTrialComponentVisibility.subscribe(function (visibility) { return _this.freeTrialComponentVisible = visibility; });
        this.greenTee918Service.castPinFormComponentVisibility.subscribe(function (visibility) {
            return _this.freeUserPinFormComponentVisible = visibility;
        });
    };
    MainContentComponent.prototype.setMainMenuClasses = function () {
        var classes = {
            'main-menu': true
        };
        return classes;
    };
    MainContentComponent.prototype.setMainContentClasses = function () {
        var classes = {
            'gt-main-content-container': true
        };
        return classes;
    };
    MainContentComponent.prototype.setHomeClasses = function () {
        var classes = {};
        return classes;
    };
    MainContentComponent.prototype.setGolferClasses = function () {
        var classes = {
            golfer: true
        };
        return classes;
    };
    MainContentComponent.prototype.setClubAdminClasses = function () {
        var classes = {
            'club-admin': true
        };
        return classes;
    };
    MainContentComponent.prototype.setAdminClasses = function () {
        var classes = {
            admin: true
        };
        return classes;
    };
    MainContentComponent.prototype.setAboutClasses = function () {
        var classes = {
            about: true
        };
        return classes;
    };
    MainContentComponent.prototype.setProfileClasses = function () {
        var classes = {
            profile: true
        };
        return classes;
    };
    MainContentComponent = tslib_1.__decorate([
        Component({
            selector: 'app-main-content',
            templateUrl: './main-content.component.html',
            styleUrls: ['../../app.component.css', './main-content.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], MainContentComponent);
    return MainContentComponent;
}());
export { MainContentComponent };
//# sourceMappingURL=main-content.component.js.map