import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var LoginComponent = (function () {
    function LoginComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.loginFormComponentVisible = true;
        this.forgotPasswordComponentVisible = false;
        this.passwordResetEmailComponentVisible = false;
        this.passwordResetPhoneComponentVisible = false;
        this.passwordResetComponentVisible = false;
        this.pinFormComponentVisible = false;
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent.prototype.setTopLevelContainerClasses = function () {
        var classes = {
            topLevelConatainer: true
        };
        return classes;
    };
    LoginComponent.prototype.setClasses = function () {
        var classes = {
            'full-display-container': true
        };
        return classes;
    };
    LoginComponent.prototype.setHeaderClasses = function () {
        var classes = {
            'login-header': true
        };
        return classes;
    };
    LoginComponent.prototype.setFullViewContainerClasses = function () {
        var classes = {
            fullViewContainer: true
        };
        return classes;
    };
    LoginComponent.prototype.setLoginContainerClasses = function () {
        var classes = {
            'gt-main-content-container': true
        };
        return classes;
    };
    LoginComponent.prototype.setLoginFormClasses = function () {
        var classes = {
            'login-form': true
        };
        return classes;
    };
    LoginComponent.prototype.setAboutClasses = function () {
        var classes = {
            about: true
        };
        return classes;
    };
    LoginComponent.prototype.cancel = function () {
        this.greenTee918Service.hideLoginComponent();
    };
    LoginComponent = tslib_1.__decorate([
        Component({
            selector: 'app-login',
            templateUrl: './login.component.html',
            styleUrls: ['../../app.component.css', './login.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], LoginComponent);
    return LoginComponent;
}());
export { LoginComponent };
//# sourceMappingURL=login.component.js.map