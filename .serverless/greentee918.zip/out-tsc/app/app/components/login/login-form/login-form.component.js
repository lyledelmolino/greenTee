import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { Greentee918Service } from '../../../services/greentee918.service';
var LoginFormComponent = (function () {
    function LoginFormComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
    }
    LoginFormComponent.prototype.ngOnInit = function () {
    };
    LoginFormComponent.prototype.setLoginFormClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    LoginFormComponent.prototype.loginUser = function () {
        this.greenTee918Service.loginUser(this.username, this.password, this.router);
    };
    LoginFormComponent.prototype.cancel = function () {
        this.greenTee918Service.hideLoginComponent();
        this.greenTee918Service.showHomeComponent();
    };
    LoginFormComponent.prototype.showForgotPasswordComponent = function () {
        this.greenTee918Service.showForgotPasswordComponent();
        this.greenTee918Service.hideLoginFormComponent();
    };
    LoginFormComponent.prototype.showPasswordResetEmailComponent = function () {
        this.greenTee918Service.showPasswordResetEmailComponent();
        this.greenTee918Service.hideLoginFormComponent();
    };
    LoginFormComponent.prototype.showRegisterFreeUserComponent = function () {
        this.greenTee918Service.hideLoginComponent();
        this.greenTee918Service.showRegisterFreeTrialUserComponent();
    };
    LoginFormComponent.prototype.setLoginContainerClasses = function () {
        var classes = {
            'login-container': true
        };
        return classes;
    };
    LoginFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-login-form',
            templateUrl: './login-form.component.html',
            styleUrls: ['../../../app.component.css', './login-form.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], LoginFormComponent);
    return LoginFormComponent;
}());
export { LoginFormComponent };
//# sourceMappingURL=login-form.component.js.map