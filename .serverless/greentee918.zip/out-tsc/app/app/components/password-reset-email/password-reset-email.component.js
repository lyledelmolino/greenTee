import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { Greentee918Service } from '../../services/greentee918.service';
var PasswordResetEmailComponent = (function () {
    function PasswordResetEmailComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
    }
    PasswordResetEmailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castPasswordResetEmailErrorMsgComponentVisibility
            .subscribe(function (visibility) {
            _this.message_fail = visibility;
        });
    };
    PasswordResetEmailComponent.prototype.cancel = function () {
        this.greenTee918Service.hidePasswordResetEmailErrorMsgComponent();
        this.greenTee918Service.hidePasswordResetEmailComponent();
        this.greenTee918Service.showLoginFormComponent();
    };
    PasswordResetEmailComponent.prototype.emailKeypress = function () {
        this.message_fail = false;
    };
    PasswordResetEmailComponent.prototype.initializePasswordReset = function () {
        console.log("initializePasswordReset()");
        this.greenTee918Service.initializePasswordReset(this.email);
        this.router.navigate(['../initialize-password-reset']);
    };
    PasswordResetEmailComponent.prototype.setResetPasswordEmailFormClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    PasswordResetEmailComponent.prototype.setResetPasswordEmailContainerClasses = function () {
        var classes = {
            'login-container': true
        };
        return classes;
    };
    PasswordResetEmailComponent = tslib_1.__decorate([
        Component({
            selector: 'app-password-reset-email',
            templateUrl: './password-reset-email.component.html',
            styleUrls: ['../../app.component.css', './password-reset-email.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], PasswordResetEmailComponent);
    return PasswordResetEmailComponent;
}());
export { PasswordResetEmailComponent };
//# sourceMappingURL=password-reset-email.component.js.map