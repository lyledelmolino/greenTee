import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Router } from "@angular/router";
import { Greentee918Service } from '../../services/greentee918.service';
var PinFormComponent = (function () {
    function PinFormComponent(greenTee918Service, router) {
        this.greenTee918Service = greenTee918Service;
        this.router = router;
    }
    PinFormComponent.prototype.ngOnInit = function () {
    };
    PinFormComponent.prototype.cancel = function () {
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.showLoginFormComponent();
    };
    PinFormComponent.prototype.confirmPin = function () {
        console.log('In PinFormComponent.ts ---> confirmPin()');
        this.greenTee918Service.confirmPin(this.pin, this.router);
    };
    PinFormComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true,
            'profile-group-component': true
        };
        return classes;
    };
    PinFormComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    PinFormComponent.prototype.setProfileClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    PinFormComponent = tslib_1.__decorate([
        Component({
            selector: 'app-pin-form',
            templateUrl: './pin-form.component.html',
            styleUrls: ['../../app.component.css', './pin-form.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service, Router])
    ], PinFormComponent);
    return PinFormComponent;
}());
export { PinFormComponent };
//# sourceMappingURL=pin-form.component.js.map