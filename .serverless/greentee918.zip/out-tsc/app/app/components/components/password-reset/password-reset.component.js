import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var PasswordResetComponent = (function () {
    function PasswordResetComponent() {
    }
    PasswordResetComponent.prototype.ngOnInit = function () {
    };
    PasswordResetComponent = tslib_1.__decorate([
        Component({
            selector: 'app-password-reset',
            templateUrl: './password-reset.component.html',
            styleUrls: ['./password-reset.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], PasswordResetComponent);
    return PasswordResetComponent;
}());
export { PasswordResetComponent };
//# sourceMappingURL=password-reset.component.js.map