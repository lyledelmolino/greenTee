import * as tslib_1 from "tslib";
import { Component, ElementRef } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var PasswordResetPhoneComponent = (function () {
    function PasswordResetPhoneComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
    }
    PasswordResetPhoneComponent.prototype.ngOnInit = function () {
    };
    PasswordResetPhoneComponent.prototype.cancel = function () {
        this.greenTee918Service.hidePasswordResetPhoneComponent();
        this.greenTee918Service.showForgotPasswordComponent();
    };
    PasswordResetPhoneComponent.prototype.setResetPasswordPhoneFormClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    PasswordResetPhoneComponent.prototype.setResetPasswordPhoneContainerClasses = function () {
        var classes = {
            'login-container': true
        };
        return classes;
    };
    PasswordResetPhoneComponent.prototype.inputOnlyInteger = function (e, maxlength) {
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)
            && e.keyCode !== 8
            && e.keyCode !== 46
            && e.keyCode !== 37
            && e.keyCode !== 39
            && e.keyCode !== 9) {
            e.preventDefault();
            return;
        }
        if (typeof maxlength !== 'undefined' && maxlength != null
            && e.target.value.length >= maxlength
            && e.keyCode !== 8
            && e.keyCode !== 46
            && e.keyCode !== 37
            && e.keyCode !== 39
            && e.keyCode !== 9) {
            e.preventDefault();
            return;
        }
    };
    PasswordResetPhoneComponent.prototype.checkInputForTab = function (e) {
        if (e.target.value.length === 3) {
            var next = new ElementRef(e.target.nextSibling);
            next.nativeElement.focus();
            e.target.value = e.target.value;
        }
    };
    PasswordResetPhoneComponent.prototype.initializeResetPassword = function () {
        this.greenTee918Service.initializePasswordReset(this.componentForm);
    };
    PasswordResetPhoneComponent = tslib_1.__decorate([
        Component({
            selector: 'app-password-reset-phone',
            templateUrl: './password-reset-phone.component.html',
            styleUrls: ['../../app.component.css', './password-reset-phone.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], PasswordResetPhoneComponent);
    return PasswordResetPhoneComponent;
}());
export { PasswordResetPhoneComponent };
//# sourceMappingURL=password-reset-phone.component.js.map