import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var AboutComponent = (function () {
    function AboutComponent() {
    }
    AboutComponent.prototype.ngOnInit = function () {
    };
    AboutComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true
        };
        return classes;
    };
    AboutComponent.prototype.setDetailClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    AboutComponent = tslib_1.__decorate([
        Component({
            selector: 'app-about',
            templateUrl: './about.component.html',
            styleUrls: ['./about.component.css', '../../app.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], AboutComponent);
    return AboutComponent;
}());
export { AboutComponent };
//# sourceMappingURL=about.component.js.map