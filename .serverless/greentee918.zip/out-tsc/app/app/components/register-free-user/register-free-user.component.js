import * as tslib_1 from "tslib";
import { Component, ElementRef } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
import { User } from '../../models/User';
var RegisterFreeUserComponent = (function () {
    function RegisterFreeUserComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.addressDetailVisible = false;
        this.phoneDetailVisible = false;
        this.updatedUser = new User();
        this.zipCodeNumberOnly = "";
        this.zipCodePlus4NumberOnly = "";
        this.componentForm = new User();
    }
    RegisterFreeUserComponent.prototype.ngOnInit = function () {
    };
    RegisterFreeUserComponent.prototype.initializeRegisterFreeUser = function () {
        this.componentForm.username = this.componentForm.emails[0];
        console.log('In RegisterFreeUserComponent ---> initializeRegisterFreeUser()');
        console.log(this.componentForm);
        this.greenTee918Service.initializeRegisterFreeUser(this.componentForm);
    };
    RegisterFreeUserComponent.prototype.inputOnlyIntegerZip = function (e) {
        var input = parseInt(e.key);
        if ((e.shiftKey || (isNaN(input)))
            && e.key !== "Backspace"
            && e.key !== " "
            && e.key !== "Delete"
            && e.key !== 37
            && e.key !== 39
            && e.key !== 9) {
            this.componentForm.locations[0].aAddress.zipCode = this.zipCodeNumberOnly;
            return;
        }
        this.zipCodeNumberOnly = this.componentForm.locations[0].aAddress.zipCode;
        return;
    };
    RegisterFreeUserComponent.prototype.inputOnlyIntegerZipPlus4 = function (e) {
        var input = parseInt(e.key);
        if ((e.shiftKey || (isNaN(input)))
            && e.key !== "Backspace"
            && e.key !== " "
            && e.key !== "Delete"
            && e.key !== 37
            && e.key !== 39
            && e.key !== 9) {
            this.componentForm.locations[0].aAddress.zipPlus4 = this.zipCodePlus4NumberOnly;
            return;
        }
        this.zipCodeNumberOnly = this.componentForm.locations[0].aAddress.zipCode;
        return;
    };
    RegisterFreeUserComponent.prototype.checkInputForTab = function (e) {
        if (e.target.value.length === 3) {
            var next = new ElementRef(e.target.nextSibling);
            next.nativeElement.focus();
            e.target.value = e.target.value;
        }
    };
    RegisterFreeUserComponent.prototype.resetForm = function () {
    };
    RegisterFreeUserComponent.prototype.emailKeypress = function () {
        this.message_fail = false;
    };
    RegisterFreeUserComponent.prototype.toggleAffiliationsDetailVisible = function () {
    };
    RegisterFreeUserComponent.prototype.toggleAddressDetailVisible = function () {
        this.addressDetailVisible = !this.addressDetailVisible;
    };
    RegisterFreeUserComponent.prototype.toggleEmailDetailVisible = function () {
    };
    RegisterFreeUserComponent.prototype.togglePhoneDetailVisible = function () {
        this.phoneDetailVisible = !this.phoneDetailVisible;
    };
    RegisterFreeUserComponent.prototype.setAddressContainerClasses = function () {
        var classes = {
            address: true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            'form-largest': true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'container-container': true,
            'profile-group-component': true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setDetailContainerClasses = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setProfileClasses = function () {
        var classes = {
            'profile-form': true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setProfileDetailContainerClasses = function () {
        var classes = {
            'profile-detail': true
        };
        return classes;
    };
    RegisterFreeUserComponent.prototype.setProfileAffiliationsDetailContainerClasses = function () {
        var classes = {
            'profile-affiliations-detail': true
        };
        return classes;
    };
    RegisterFreeUserComponent = tslib_1.__decorate([
        Component({
            selector: 'app-register-free-user',
            templateUrl: './register-free-user.component.html',
            styleUrls: ['../../app.component.css', './register-free-user.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], RegisterFreeUserComponent);
    return RegisterFreeUserComponent;
}());
export { RegisterFreeUserComponent };
//# sourceMappingURL=register-free-user.component.js.map