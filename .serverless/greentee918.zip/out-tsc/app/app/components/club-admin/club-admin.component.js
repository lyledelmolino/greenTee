import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
var ClubAdminComponent = (function () {
    function ClubAdminComponent() {
    }
    ClubAdminComponent.prototype.ngOnInit = function () {
    };
    ClubAdminComponent = tslib_1.__decorate([
        Component({
            selector: 'app-club-admin',
            templateUrl: './club-admin.component.html',
            styleUrls: ['./club-admin.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [])
    ], ClubAdminComponent);
    return ClubAdminComponent;
}());
export { ClubAdminComponent };
//# sourceMappingURL=club-admin.component.js.map