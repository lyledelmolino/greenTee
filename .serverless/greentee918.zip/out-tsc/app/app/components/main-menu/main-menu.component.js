import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var MainMenuComponent = (function () {
    function MainMenuComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.homeComponentVisible = true;
        this.golferComponentVisible = false;
        this.clubAdminComponentVisible = false;
        this.adminComponentVisible = false;
        this.freeTrialComponentVisible = false;
        this.aboutComponentVisible = false;
        this.responsiveMenuVisible = false;
        this.animateArrowDown = false;
        this.animateArrowUp = true;
    }
    MainMenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.greenTee918Service.castHomeComponentVisibility.subscribe(function (visibility) { return _this.homeComponentVisible = visibility; });
        this.greenTee918Service.castGolferComponentVisibility.subscribe(function (visibility) { return _this.golferComponentVisible = visibility; });
        this.greenTee918Service.castClubAdminComponentVisibility.subscribe(function (visibility) { return _this.clubAdminComponentVisible = visibility; });
        this.greenTee918Service.castAdminComponentVisibility.subscribe(function (visibility) { return _this.adminComponentVisible = visibility; });
        this.greenTee918Service.castRegisterFreeUserComponentVisibility.subscribe(function (visibility) { return _this.freeTrialComponentVisible = visibility; });
        this.greenTee918Service.castAboutComponentVisibility.subscribe(function (visibility) { return _this.aboutComponentVisible = visibility; });
        this.greenTee918Service.castResponsiveMenuVisibility.subscribe(function (visibility) { return _this.responsiveMenuVisible = visibility; });
    };
    MainMenuComponent.prototype.setArrowClasses = function () {
        var classes = {
            'animate-arrow-down': this.animateArrowDown,
            'animate-arrow-up': this.animateArrowUp
        };
        return classes;
    };
    MainMenuComponent.prototype.setHomeButtonClasses = function () {
        var classes = {
            active: this.homeComponentVisible,
            'responsive-menu': this.responsiveMenuVisible,
        };
        return classes;
    };
    MainMenuComponent.prototype.setGolferButtonClasses = function () {
        var classes = {
            active: this.golferComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.setClubAdminButtonClasses = function () {
        var classes = {
            active: this.clubAdminComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.setAdminButtonClasses = function () {
        var classes = {
            active: this.adminComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.setFreeTrialButtonClasses = function () {
        var classes = {
            active: this.freeTrialComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.setRegisterFreeUserButtonClasses = function () {
        var classes = {
            active: this.freeTrialComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.setAboutButtonClasses = function () {
        var classes = {
            active: this.aboutComponentVisible,
            'responsive-menu': this.responsiveMenuVisible
        };
        return classes;
    };
    MainMenuComponent.prototype.showResponsiveMenu = function () {
        this.responsiveMenuVisible = true;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    MainMenuComponent.prototype.showHomeComponent = function () {
        debugger;
        this.responsiveMenuVisible = false;
        this.greenTee918Service.showHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    MainMenuComponent.prototype.showGolferComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.showGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    MainMenuComponent.prototype.showClubAdminComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.showClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    MainMenuComponent.prototype.showAdminComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.showAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    MainMenuComponent.prototype.showFreeTrialComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideAboutComponent();
        this.greenTee918Service.showFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
    };
    MainMenuComponent.prototype.showRegisterFreeUserComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideAboutComponent();
        this.greenTee918Service.showRegisterFreeTrialUserComponent();
        this.greenTee918Service.hidePinFormComponent();
    };
    MainMenuComponent.prototype.showAboutComponent = function () {
        this.responsiveMenuVisible = false;
        this.greenTee918Service.hideHomeComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideFreeTrialComponent();
        this.greenTee918Service.hidePinFormComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.showAboutComponent();
    };
    MainMenuComponent = tslib_1.__decorate([
        Component({
            selector: 'app-main-menu',
            templateUrl: './main-menu.component.html',
            styleUrls: ['./main-menu.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], MainMenuComponent);
    return MainMenuComponent;
}());
export { MainMenuComponent };
//# sourceMappingURL=main-menu.component.js.map