import * as tslib_1 from "tslib";
import { BrowserTransferStateModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Greentee918Service } from './services/greentee918.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppModule } from './app.module';
var AppBrowserModule = (function () {
    function AppBrowserModule() {
    }
    AppBrowserModule = tslib_1.__decorate([
        NgModule({
            imports: [
                AppRoutingModule,
                HttpClientModule,
                FormsModule,
                BrowserAnimationsModule,
                AppModule,
                BrowserTransferStateModule,
            ],
            providers: [Greentee918Service],
            bootstrap: [AppComponent]
        })
    ], AppBrowserModule);
    return AppBrowserModule;
}());
export { AppBrowserModule };
//# sourceMappingURL=app.browser.module.js.map