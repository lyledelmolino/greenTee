import 'zone.js/dist/zone';
//# sourceMappingURL=polyfills.js.map