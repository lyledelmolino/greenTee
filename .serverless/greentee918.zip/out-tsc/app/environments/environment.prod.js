export var environment = {
    production: true,
    baseHref: '/'
};
//# sourceMappingURL=environment.prod.js.map