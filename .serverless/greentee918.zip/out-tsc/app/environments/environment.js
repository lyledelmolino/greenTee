export var environment = {
    production: false,
    baseHref: '/'
};
//# sourceMappingURL=environment.js.map