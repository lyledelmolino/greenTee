export var environment = {
    production: true,
    baseHref: '/production/'
};
//# sourceMappingURL=environment.serverless.js.map