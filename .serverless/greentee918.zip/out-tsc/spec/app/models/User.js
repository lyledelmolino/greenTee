import { Location } from "./Location";
var User = (function () {
    function User(userLevel) {
        this.emails = [];
        this.locations = [new Location()];
        this.userLevel = 0;
        if (userLevel != undefined)
            this.userLevel = userLevel;
    }
    return User;
}());
export { User };
//# sourceMappingURL=User.js.map