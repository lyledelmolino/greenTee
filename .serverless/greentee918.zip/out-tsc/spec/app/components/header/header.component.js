import * as tslib_1 from "tslib";
import { Component } from '@angular/core';
import { Greentee918Service } from '../../services/greentee918.service';
var HeaderComponent = (function () {
    function HeaderComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.loginComponentVisible = false;
        this.forgotPasswordComponentVisible = false;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
        this.greenTee918Service.castLoginVisibility.subscribe(function (visibility) { return _this.loginComponentVisible = visibility; });
        this.greenTee918Service.castForgotPasswordComponentVisibility.subscribe(function (visibility) { return _this.forgotPasswordComponentVisible = visibility; });
    };
    HeaderComponent.prototype.showHome = function () {
        this.greenTee918Service.showHomeComponent();
        this.greenTee918Service.hideLoginComponent();
        this.greenTee918Service.hideGolferComponent();
        this.greenTee918Service.hideClubAdminComponent();
        this.greenTee918Service.hideAdminComponent();
        this.greenTee918Service.hideRegisterFreeTrialUserComponent();
        this.greenTee918Service.hideAboutComponent();
    };
    HeaderComponent.prototype.setHeaderClasses = function () {
        var classes = {
            'app-header': !(this.loginComponentVisible || this.forgotPasswordComponentVisible),
            'login-header': this.loginComponentVisible || this.forgotPasswordComponentVisible,
            'user-not-logged-in': this.appUser.userLevel == 0
        };
        return classes;
    };
    HeaderComponent = tslib_1.__decorate([
        Component({
            selector: 'app-header',
            templateUrl: './header.component.html',
            styleUrls: ['./header.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], HeaderComponent);
    return HeaderComponent;
}());
export { HeaderComponent };
//# sourceMappingURL=header.component.js.map