import { async, TestBed } from '@angular/core/testing';
import { TwoLowEligibleTScoresComponent } from './two-low-eligible-t-scores.component';
describe('TwoLowEligibleTScoresComponent', function () {
    var component;
    var fixture;
    beforeEach(async(function () {
        TestBed.configureTestingModule({
            declarations: [TwoLowEligibleTScoresComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = TestBed.createComponent(TwoLowEligibleTScoresComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=two-low-eligible-t-scores.component.spec.js.map