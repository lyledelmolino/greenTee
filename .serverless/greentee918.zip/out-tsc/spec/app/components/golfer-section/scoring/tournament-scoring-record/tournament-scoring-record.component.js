import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { Greentee918Service } from '../../../../services/greentee918.service';
var TScoringRecordComponent = (function () {
    function TScoringRecordComponent(greenTee918Service) {
        this.greenTee918Service = greenTee918Service;
        this.detailVisible = false;
    }
    TScoringRecordComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.greenTee918Service.castUser.subscribe(function (user) { return _this.appUser = user; });
    };
    TScoringRecordComponent.prototype.toggleTournamentScoringRecordDetailVisible = function () {
        this.detailVisible = !this.detailVisible;
    };
    TScoringRecordComponent.prototype.setDetailActuatorClass = function () {
        var classes = {
            'detail-actuator': true,
            active: this.detailVisible
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setContainerContainerClass = function () {
        var classes = {
            'detail-container-container': true,
            'container-container-container': true
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setContainerContainerContainerClass = function () {
        var classes = {
            'container-container': true
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setScoreTableContainerClass = function () {
        var classes = {
            'score-table-container': true
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setScoringRecordContainerClass = function () {
        var classes = {
            'scoring-record-container': true
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setDetailContainerClass = function () {
        var classes = {
            'detail-container': true
        };
        return classes;
    };
    TScoringRecordComponent.prototype.setScoringRecordClass = function () {
        var classes = {
            'score-table': true
        };
        return classes;
    };
    tslib_1.__decorate([
        Input(),
        tslib_1.__metadata("design:type", Object)
    ], TScoringRecordComponent.prototype, "scores", void 0);
    TScoringRecordComponent = tslib_1.__decorate([
        Component({
            selector: 'app-tournament-scoring-record',
            templateUrl: './tournament-scoring-record.component.html',
            styleUrls: ['../../../../app.component.css', '../scoring.component.css', './tournament-scoring-record.component.css']
        }),
        tslib_1.__metadata("design:paramtypes", [Greentee918Service])
    ], TScoringRecordComponent);
    return TScoringRecordComponent;
}());
export { TScoringRecordComponent };
//# sourceMappingURL=tournament-scoring-record.component.js.map