import { async, TestBed } from '@angular/core/testing';
import { LatestRevScoringRecordComponent } from './latest-rev-scoring-record.component';
describe('LatestRevScoringRecordComponent', function () {
    var component;
    var fixture;
    beforeEach(async(function () {
        TestBed.configureTestingModule({
            declarations: [LatestRevScoringRecordComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = TestBed.createComponent(LatestRevScoringRecordComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=latest-rev-scoring-record.component.spec.js.map