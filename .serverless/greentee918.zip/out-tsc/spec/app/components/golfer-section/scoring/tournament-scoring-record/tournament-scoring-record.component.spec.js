import { async, TestBed } from '@angular/core/testing';
import { TournamentScoringRecordComponent } from './tournament-scoring-record.component';
describe('TournamentScoringRecordComponent', function () {
    var component;
    var fixture;
    beforeEach(async(function () {
        TestBed.configureTestingModule({
            declarations: [TournamentScoringRecordComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = TestBed.createComponent(TournamentScoringRecordComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=tournament-scoring-record.component.spec.js.map