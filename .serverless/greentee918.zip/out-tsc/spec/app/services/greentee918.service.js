import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { User } from '../models/User';
var HTTP_OPTIONS = {
    headers: new HttpHeaders({
        'Content-type': 'application/x-www-form-urlencoded'
    })
};
var HTTP_OPTIONS_JSON = {
    headers: new HttpHeaders({
        'Content-type': 'application/json'
    })
};
var Greentee918Service = (function () {
    function Greentee918Service(http, router) {
        this.http = http;
        this.router = router;
        this.theURL = 'https://www.greentee.info/angular/api/index.php';
        this.theGHINURL = 'http://widgets.ghin.com/HandicapLookup.aspx?entry=1&css=default&dynamic=&small=0&showheader=1&showheadertext=1&showfootertext=1&tab=1';
        this.mPinForm = "";
        this.appUser = {
            userLevel: 0
        };
        this.user = new BehaviorSubject(this.appUser);
        this.foundGolfers = new BehaviorSubject(this.mFoundGolfers);
        this.resetPasswordSessionId = new BehaviorSubject(this.mResetPasswordSessionId);
        this.sessionId = new BehaviorSubject(this.mRegisterForFreeTrialSessionId);
        this.loginComponentVisibility = new BehaviorSubject('');
        this.loginFormComponentVisibility = new BehaviorSubject('');
        this.forgotPasswordComponentVisibility = new BehaviorSubject('');
        this.passwordResetEmailComponentVisibility = new BehaviorSubject('');
        this.passwordResetEmailErrorMsgComponentVisibility = new BehaviorSubject('');
        this.passwordResetPhoneComponentVisibility = new BehaviorSubject('');
        this.passwordResetComponentVisibility = new BehaviorSubject('');
        this.homeComponentVisibility = new BehaviorSubject('');
        this.findGolferComponentVisibility = new BehaviorSubject('');
        this.golferComponentVisibility = new BehaviorSubject('');
        this.scoringComponentVisibility = new BehaviorSubject('');
        this.profileComponentVisibility = new BehaviorSubject('');
        this.clubAdminComponentVisibility = new BehaviorSubject('');
        this.adminComponentVisibility = new BehaviorSubject('');
        this.aboutComponentVisibility = new BehaviorSubject('');
        this.registerFreeUserComponentVisibility = new BehaviorSubject('');
        this.pinFormComponentVisibility = new BehaviorSubject('');
        this.freeTrialComponentVisibility = new BehaviorSubject('');
        this.freeTrialPinFormComponentVisibility = new BehaviorSubject('');
        this.responsiveMenuVisibility = new BehaviorSubject('');
        this.castUser = this.user.asObservable();
        this.castFoundGolfers = this.foundGolfers.asObservable();
        this.castRegisterForFreeTrialSessionId = this.sessionId.asObservable();
        this.castLoginVisibility = this.loginComponentVisibility.asObservable();
        this.castLoginFormComponentVisibility = this.loginFormComponentVisibility.asObservable();
        this.castForgotPasswordComponentVisibility = this.forgotPasswordComponentVisibility.asObservable();
        this.castPasswordResetEmailComponentVisibility = this.passwordResetEmailComponentVisibility.asObservable();
        this.castPasswordResetEmailErrorMsgComponentVisibility = this.passwordResetEmailErrorMsgComponentVisibility.asObservable();
        this.castPasswordResetPhoneComponentVisibility = this.passwordResetPhoneComponentVisibility.asObservable();
        this.castPasswordResetComponentVisibility = this.passwordResetComponentVisibility.asObservable();
        this.castHomeComponentVisibility = this.homeComponentVisibility.asObservable();
        this.castFindGolferComponentVisibility = this.findGolferComponentVisibility.asObservable();
        this.castGolferComponentVisibility = this.golferComponentVisibility.asObservable();
        this.castScoringComponentVisibility = this.scoringComponentVisibility.asObservable();
        this.castProfileComponentVisibility = this.profileComponentVisibility.asObservable();
        this.castClubAdminComponentVisibility = this.clubAdminComponentVisibility.asObservable();
        this.castAdminComponentVisibility = this.adminComponentVisibility.asObservable();
        this.castAboutComponentVisibility = this.aboutComponentVisibility.asObservable();
        this.castRegisterFreeUserComponentVisibility = this.registerFreeUserComponentVisibility.asObservable();
        this.castPinFormComponentVisibility = this.pinFormComponentVisibility.asObservable();
        this.castFreeTrialComponentVisibility = this.freeTrialComponentVisibility.asObservable();
        this.castFreeTrialPinFormComponentVisibility = this.freeTrialPinFormComponentVisibility.asObservable();
        this.castResponsiveMenuVisibility = this.responsiveMenuVisibility.asObservable();
    }
    Greentee918Service.prototype.logoutUser = function (router) {
        this.user.next(new User(0));
        router.navigate(['../home']);
    };
    Greentee918Service.prototype.loginUser = function (username, password, router) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('username', username);
        body = body.set('password', password);
        body = body.set('action', 'login_api');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (loggedInUser) {
            _this.user.next(loggedInUser);
            if (loggedInUser.userLevel > 0) {
                _this.loginComponentVisibility.next(false);
                _this.hideHomeComponent();
                _this.showGolferComponent();
                router.navigate(['../golfer']);
            }
            console.log('In greentee918.service.ts ---> loginUser(): Observable<User>');
            console.log(_this.user.value.revisionScoringRecord);
            console.log(_this.user.value);
        });
    };
    Greentee918Service.prototype.initializePasswordReset = function (pEmail) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('email', pEmail);
        body = body.set('action', 'init_reset_password');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (sessionId) {
            _this.mResetPasswordSessionId = sessionId;
            if (sessionId != 'fail') {
                _this.hidePasswordResetEmailComponent();
                _this.showPinFormComponent();
            }
            else {
                _this.showPasswordResetEmailErrorMsgComponent();
            }
        });
    };
    Greentee918Service.prototype.confirmPin = function (pPin, router) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('pin', pPin);
        body = body.set('ob_tacgod', this.mResetPasswordSessionId);
        if (this.mPinForm == "register-free-user") {
            body = body.set('action', 'finalize_free_trial');
        }
        else {
            body = body.set('action', 'confirm_pin');
        }
        console.log('In greentee918.service.ts ---> confirmPin(pin: string, sessionId: string)  - this.mResetPasswordSessionId:');
        console.log(this.mResetPasswordSessionId);
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (sessionId) {
            _this.mResetPasswordSessionId = sessionId;
            if (sessionId != 0) {
                _this.hidePinFormComponent();
                if (_this.mPinForm == "register-free-user") {
                    _this.user.next(sessionId);
                    if (sessionId.userLevel > 0) {
                        router.navigate(['../home']);
                    }
                }
                else {
                    router.navigate(['../password-reset']);
                }
            }
            else {
            }
        });
    };
    Greentee918Service.prototype.resetPassword = function (pPassword, router) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('rehto', pPassword);
        body = body.set('ob_tacgod', this.mResetPasswordSessionId);
        body = body.set('action', 'reset_password');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (loggedInUser) {
            _this.user.next(loggedInUser);
            if (loggedInUser.userLevel > 0) {
                router.navigate(['../home']);
            }
        });
    };
    Greentee918Service.prototype.initializeRegisterFreeUser = function (pUser) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('form', JSON.stringify(pUser));
        body = body.set('action', 'initialize_free_trial');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (sessionId) {
            console.log('In greentee918.service.ts ---> -initializeRegisterFreeUser(pUser: User) sessionId:');
            console.log(sessionId);
            _this.mResetPasswordSessionId = sessionId;
            if (sessionId == 'username_exists' || sessionId == 'email_exists') {
                _this.sessionId.next(sessionId);
            }
            else {
                _this.sessionId.next(sessionId);
                _this.hideRegisterFreeTrialUserComponent();
                _this.showPinFormComponent();
                _this.mPinForm = "register-free-user";
            }
            console.log('In greentee918.service.ts ---> -initializeRegisterFreeUser(pUser: User) sessionId:');
            console.log(_this.sessionId);
        });
    };
    Greentee918Service.prototype.confirmFreeUserRegistrationPin = function (pPin) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('pin', pPin);
        body = body.set('ob_tacgod', this.mResetPasswordSessionId);
        body = body.set('action', 'finalize_free_trial');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (loggedInUser) {
            if (loggedInUser != 0) {
                _this.user.next(loggedInUser);
                if (loggedInUser.userLevel > 0) {
                    _this.hidePinFormComponent();
                    _this.showHomeComponent();
                }
            }
            else {
            }
        });
    };
    Greentee918Service.prototype.registerFreeUser = function (pUser) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('action', 'finalize_free_trial');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (appUser) {
            _this.user.next(appUser);
            _this.hidePinFormComponent();
            _this.showHomeComponent();
        });
    };
    Greentee918Service.prototype.findGolfer = function (formData) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('form', JSON.stringify(formData));
        body = body.set('action', 'find_golfer');
        console.log('A1A - In greentee918.service.ts ---> -findGolfer(golferToFind)');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (foundGolfers) {
            console.log('In greentee918.service.ts ---> -findGolfer(golferToFind)');
            console.log(foundGolfers.length);
            console.log('formData: ' + formData);
            console.log('stringified formData: ' + JSON.stringify(formData));
            if (foundGolfers.length == 0) {
                console.log('formData.lastName: ' + formData.lastName);
                var httpHeaders = new HttpHeaders()
                    .set('Access-Control-Allow-Origin', 'http://localhost:4200')
                    .set('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:12.0)');
                _this.http.get('http://google.com', { headers: httpHeaders }).subscribe(function (data) {
                    console.log('returned data: ' + data);
                });
            }
            else {
                _this.foundGolfers.next(foundGolfers);
            }
        });
    };
    Greentee918Service.prototype.parseGHINFoundGolfers = function (foundGolfers) {
    };
    Greentee918Service.prototype.postScore = function (formData) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('form', JSON.stringify(formData));
        body = body.set('action', 'post_score_api');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (loggedInUser) {
            _this.user.next(loggedInUser);
            if (loggedInUser.userLevel > 0) {
                _this.loginComponentVisibility.next(false);
            }
        });
    };
    Greentee918Service.prototype.updateUserProfile = function (formData) {
        var _this = this;
        var body = new HttpParams();
        body = body.set('form', JSON.stringify(formData));
        body = body.set('action', 'update_user');
        this.http.post(this.theURL, body, HTTP_OPTIONS)
            .subscribe(function (updatedUser) {
            updatedUser.handicapIndex = formData.handicapIndex;
            updatedUser.currentScoringRecord = formData.currentScoringRecord;
            updatedUser.eligibleTournamentScoringRecord = formData.eligibleTournamentScoringRecord;
            updatedUser.revisionScoringRecord = formData.revisionScoringRecord;
            updatedUser.twoLowestEligibleTournamentScores = formData.twoLowestEligibleTournamentScores;
            _this.user.next(updatedUser);
            if (updatedUser.userLevel > 0) {
                _this.loginComponentVisibility.next(false);
            }
        });
    };
    Greentee918Service.prototype.showLoginComponent = function () {
    };
    Greentee918Service.prototype.hideLoginComponent = function () {
    };
    Greentee918Service.prototype.showLoginFormComponent = function () {
    };
    Greentee918Service.prototype.hideLoginFormComponent = function () {
    };
    Greentee918Service.prototype.hideFoundGolfersComponent = function () {
    };
    Greentee918Service.prototype.showForgotPasswordComponent = function () {
    };
    Greentee918Service.prototype.hideForgotPasswordComponent = function () {
    };
    Greentee918Service.prototype.hideResponsiveMenu = function () {
    };
    Greentee918Service.prototype.showPasswordResetEmailComponent = function () {
    };
    Greentee918Service.prototype.hidePasswordResetEmailComponent = function () {
        this.passwordResetEmailComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showPasswordResetEmailErrorMsgComponent = function () {
        this.passwordResetEmailErrorMsgComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hidePasswordResetEmailErrorMsgComponent = function () {
        this.passwordResetEmailErrorMsgComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showPasswordResetPhoneComponent = function () {
        this.passwordResetPhoneComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hidePasswordResetPhoneComponent = function () {
        this.passwordResetPhoneComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showPasswordResetComponent = function () {
        this.passwordResetComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hidePasswordResetComponent = function () {
        this.passwordResetComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showHomeComponent = function () {
        this.homeComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideHomeComponent = function () {
        this.homeComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showGolferComponent = function () {
        this.golferComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideGolferComponent = function () {
        this.golferComponentVisibility.next(false);
        this.hideScoringComponent();
        this.hideProfileComponent();
    };
    Greentee918Service.prototype.showScoringComponent = function () {
        this.scoringComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideScoringComponent = function () {
        this.scoringComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showProfileComponent = function () {
        this.profileComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideProfileComponent = function () {
        this.profileComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showClubAdminComponent = function () {
        this.clubAdminComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideClubAdminComponent = function () {
        this.clubAdminComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showAdminComponent = function () {
        this.adminComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideAdminComponent = function () {
        this.adminComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showAboutComponent = function () {
        this.aboutComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideAboutComponent = function () {
        this.aboutComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showRegisterFreeTrialUserComponent = function () {
        this.registerFreeUserComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideRegisterFreeTrialUserComponent = function () {
        this.registerFreeUserComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showFreeTrialComponent = function () {
        this.freeTrialComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hideFreeTrialComponent = function () {
        this.freeTrialComponentVisibility.next(false);
    };
    Greentee918Service.prototype.showPinFormComponent = function () {
        this.pinFormComponentVisibility.next(true);
    };
    Greentee918Service.prototype.hidePinFormComponent = function () {
        this.pinFormComponentVisibility.next(false);
    };
    Greentee918Service = tslib_1.__decorate([
        Injectable({
            providedIn: 'root'
        }),
        tslib_1.__metadata("design:paramtypes", [HttpClient, Router])
    ], Greentee918Service);
    return Greentee918Service;
}());
export { Greentee918Service };
//# sourceMappingURL=greentee918.service.js.map