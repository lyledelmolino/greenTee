import { TestBed } from '@angular/core/testing';
import { Greentee918Service } from './greentee918.service';
describe('Greentee918Service', function () {
    beforeEach(function () { return TestBed.configureTestingModule({}); });
    it('should be created', function () {
        var service = TestBed.get(Greentee918Service);
        expect(service).toBeTruthy();
    });
});
//# sourceMappingURL=greentee918.service.spec.js.map