import { TestBed } from '@angular/core/testing';
import { GreenteeService } from './greentee.service';
describe('GreenteeService', function () {
    beforeEach(function () { return TestBed.configureTestingModule({}); });
    it('should be created', function () {
        var service = TestBed.get(GreenteeService);
        expect(service).toBeTruthy();
    });
});
//# sourceMappingURL=greentee.service.spec.js.map